/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Kye
 */
public class Amigo extends Pessoa {
    
    private long numTelefone;
    private String email;
    private String endereco;
    private FaixaEtaria faixaEtaria;
    
    public Amigo() {
        
    }
    
    public void finalize() throws Throwable {
        super.finalize();
    }

}
