/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Kye
 */
public class CadastroAmigo {
    
    private Amigo amigos[];
    
    public CadastroAmigo() {
    
}
    
    public void finalize() throws Throwable {
    
}
    public void inclui(Amigo amigo) {
    
}
    public void altera (int amigo) {
    
}
    public void exclui (int amigo) {
    
}

}
