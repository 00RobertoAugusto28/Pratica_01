/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Kye
 */
public class Interface {
    
    public RelatorioEmprestimos relatorioEmprestimos;
    
    public Interface() {
        
    }
    
    public void finalize() throws Throwable {
        
    }
    
    public void imprime(String string) {
        
    }
    
    public void imprimeMenu() {
        
    }
    
    public DVD leDVD() {
        return null;
        
    }
    
    public Amigo leAmigo() {
        return null;
        
    }
    
    public void leEmprestimo() {
        
    }
    
    public void alteraFaixaEtaria(Amigo amigo, DVD dvd) {
        
    }

}
