/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Kye
 */
public class DVD {
    private String titulo;
    private String sinopse;
    private Genero genero;
    private Pessoa artistaPrincipal;
    private FaixaEtaria classificacao;
    
    public DVD() {
    
}
    
    public void finalize() throws Throwable {
    
}

}
